export const setTitle = (title) => {
  document.title = `${title} - MegaMart`;
};
