export const selectCartOpen = (state) => state.cartOpen.cartOpen;
